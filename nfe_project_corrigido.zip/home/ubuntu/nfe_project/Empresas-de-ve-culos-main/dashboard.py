"""Painel Streamlit principal alimentado pelo pipeline real."""

from painel import main

if __name__ == "__main__":  # pragma: no cover
    main()
